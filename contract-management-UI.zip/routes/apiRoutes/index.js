const express = require('express')
const router = express.Router()

/*add contract routes*/
const contacts = require('../../src/api/contracts')
router.post('/add-contract', contacts.addContract)
router.post('/get-contract-list', contacts.getContractList)
router.post('/remove-contract', contacts.removeContract)

module.exports = router
