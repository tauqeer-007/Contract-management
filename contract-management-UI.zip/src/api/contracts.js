const { Validator } = require('node-input-validator')
const fs = require('fs');

//
// ──────────────────────────────────────────────────────────────── I ──────────
//   :::::: A D D   C O N T R A C T : :  :   :    :     :        :          :
// ──────────────────────────────────────────────────────────────────────────
//



exports.addContract = function (req, res) {

    const { locationID } = req.body
    const validator = new Validator(req.body, {
        locationID: 'required|digitsBetween:4,8'
    })

    validator.check().then((matched) => {
        if (!matched) {
            res.status(422).send({ "success": false, "errors": validator.errors })

        }
    })
    if (Object.keys(validator.errors).length !== 0) {
        res.send({
            success: false,
            message: "Location ID digit must be in between 4 to 8"
        })
    } else {
        let file = req.files.file
        // size validation 1 kb to 2 mb
        if (file.size < 1024 || file.size > 2097152) {
            res.send({
                success: false,
                message: "File size must be between 1kb to 2mb"
            })
        }
        try {
            
            let fileName = Date.now() + '_' + file.name
            let fileTrimName = fileName.replace(/ /g,"_");
            file.mv('./uploads/' + locationID + '/' + fileTrimName)

            let contracts = getContractsByLocation(locationID)

            let r = {
                success: true,
                message: 'File uploaded successfully',
                contracts
            }
            res.json(r)
        }
        catch (err) {
            res.status(500).send({ "success": false, message: err.toString(), code: "unexpected_error" })
        }
    }


}


//
// ────────────────────────────────────────────────────────────────────────── I ──────────
//   :::::: G E T   C O N T R A C T   L I S T  B Y   L O C A T I O N     : :  :   :    :     :        :          :
// ────────────────────────────────────────────────────────────────────────────────────
//



exports.getContractList = function (req, res) {

    const { locationID } = req.body
    const validator = new Validator(req.body, {
        locationID: 'required|digitsBetween:4,8'
    })

    validator.check().then((matched) => {
        if (!matched) {
            res.status(422).send({ "success": false, "errors": validator.errors })

        }
    })

    if (Object.keys(validator.errors).length !== 0) {
        res.send({
            success: false,
            message: validator.errors
        })
    }
    try {
        let contracts = getContractsByLocation(locationID)
        res.status(200)
        res.json({ "success": true, contracts })
    }
    catch (err) {
        res.status(500).send({ "success": false, message: err.toString(), code: "unexpected_error" })

    }

}


//
// ────────────────────────────────────────────────────────────────────── I ──────────
//   :::::: R E M O V E   C O N T R A C T : :  :   :    :     :        :          :
// ────────────────────────────────────────────────────────────────────────────────
//



exports.removeContract = function (req, res) {

    const { locationID, fileName } = req.body
    const validator = new Validator(req.body, {
        locationID: 'required|digitsBetween:4,8',
        fileName: 'required'
    })

    validator.check().then((matched) => {
        if (!matched) {
            res.status(422).send({ "success": false, "errors": validator.errors })

        }
    })

    if (Object.keys(validator.errors).length !== 0) {
        res.send({
            success: false,
            message: validator.errors
        })
    }

    const pathToFile = './uploads/' + locationID + "/" + fileName

    try {
        fs.unlinkSync(pathToFile)
        let contracts = getContractsByLocation(locationID)
        res.status(200)
        res.json({ success: true, "message": "Contract successfully deleted", contracts })
    } catch (err) {
        res.status(500).send({ "success": false, message: err.toString(), code: "unexpected_error" })
    }

}

function getContractsByLocation(locationID) {
    let dir = './uploads/' + locationID
    let files = fs.readdirSync(dir)
    let data = { files }
    return data

}


