const { Validator } = require('node-input-validator')
const path = require('path')

//
// ──────────────────────────────────────────────────────────────── I ──────────
//   :::::: M A I N    P A G E : :  :   :    :     :        :          :
// ──────────────────────────────────────────────────────────────────────────
//



exports.contractForm = function (req, res) {
    
    let params = { "action": process.env.URL + '/add-contract' }
    let file = path.resolve(__dirname, `../../views/main`)
    res.render(file, params);
    
}