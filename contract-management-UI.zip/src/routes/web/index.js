const express = require('express')
const router = express.Router()

/*add contract routes*/
const contracts = require('../../frontend/contracts')
router.get('/', contracts.contractForm)

module.exports = router
