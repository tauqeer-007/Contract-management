$(document).ready(function () {
    $('#location_id').on('keyup', function () {

        let location = $(this).val()
        if (location.length >= 4 && location.length <= 8) {
            $.ajax({
                type: 'post',
                dataType: 'json',
                url: '/api/get-contract-list',
                data: {
                    locationID: location

                },
                success: function (response) {
                    if (response.success == true) {
                        let html = "<div>";
                        for (let i = 0; i < response.contracts.files.length; i++) {
                            html += "<div class='row remove_div'>";
                            html += "<div id='removeRow'><button type='button'  class='remove_contract btn btn-danger' id = " + location + '-' + response.contracts.files[i] + "  contract-data=" + response.contracts.files[i] + " location-data=" + location + " title='Remove this row'><i class='fa fa-close remove_contract'></i></button></div>";
                            html += "<div class='form-group col-lg-4 col-md-4 col-sm-4 col-xs-12'><label class='control-label'>" + response.contracts.files[i] + "</label></div>";
                            html += "</div>";
                        }
                        html += "</div>";
                        $("#contracts").empty();
                        $("#err").empty()
                        $('#err').removeClass('alert alert-danger');
                        $("#contracts").html(html);

                    }
                    else {
                        $("#contracts").empty();
                        $("#contracts").html('');
                        $("#err").empty()
                        $('#err').addClass('alert alert-danger');
                        $("#err").html("No any contracts")
                    }


                },
                error: function (xhr, status, error) {
                    let errorMessage = xhr.status + ': ' + xhr.statusText
                    console.log('Error - ' + errorMessage);
                    $("#contracts").empty();
                    $("#contracts").html('');
                    $("#err").empty()
                    $('#err').addClass('alert alert-danger');
                    $("#err").html("No any contracts")
                }
            });
        }
        else {
            $("#contracts").empty();
            $("#err").empty()
            $('#err').removeClass('alert alert-danger');
        }
    });

    $('body').on('click', 'button.remove_contract', function () {
        let id = $(this).attr('id');
        let contract = $(this).attr('contract-data');
        let locationId = $(this).attr('location-data');
        $.ajax({
            url: '/api/remove-contract',
            dataType: "json",
            type: 'post',
            data: {
                locationID: locationId,
                fileName: contract
            },
            success: function (data) {

                console.log(data);
            }
        });
    });

    $('body').on('click', 'button.remove_contract', function () {
        $(this).closest('div.remove_div').remove();
        return false;
    });


    $('#upload_form').submit(function (event) {
        event.preventDefault();

        let formEl = $(this);
        let submitButton = $('input[type=submit]', formEl);

        $.ajax({
            type: 'POST',
            url: formEl.prop('action'),
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function () {
                submitButton.prop('disabled', 'disabled');
            },
            success: function (response) {
                $('#msg').empty();
                if (response.success == true) {
                    $('#msg').addClass('alert alert-success');
                    $('#msg').html(response.message);
                }
                else {
                    $('#msg').addClass('alert alert-danger');
                    $('#msg').html(response.message);
                }
            }
        }).done(function (data) {
            submitButton.prop('disabled', false);
        });
    });
});
