const express = require('express')
const http = require('http')
const app = express()
const path = require('path')
const bodyParser = require('body-parser')
const fileUpload = require('express-fileupload');
const apiRoutes = require('./src/routes/api')
const webRoutes = require('./src/routes/web')


app.set('port', process.env.PORT || 3000)

app.use(express.json());
app.use(bodyParser.json())
app.use(fileUpload({
  createParentPath: true,  
}));
app.set("view engine", "ejs")
app.set('views', path.join(__dirname, 'views'))
app.use(bodyParser.urlencoded({extended: false}))
app.use(express.static('public'));
app.use('/' ,webRoutes)
app.use('/api' ,apiRoutes)

module.exports = app

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'))
})
